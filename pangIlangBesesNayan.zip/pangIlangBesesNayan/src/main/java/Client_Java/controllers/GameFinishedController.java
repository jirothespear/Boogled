package Client_Java.controllers;

public class GameFinishedController {
}
