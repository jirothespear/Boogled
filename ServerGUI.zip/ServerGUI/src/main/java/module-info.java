module edu.servergui {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.desktop;

    opens edu.servergui to javafx.fxml;
    exports edu.servergui;
}