module org.example.comproggui {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.comproggui to javafx.fxml;
    exports org.example.comproggui;
}